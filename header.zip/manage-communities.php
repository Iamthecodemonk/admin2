<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>admin</title>

    <!-- Google fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" sizes="16x16" href="images/favicon.png">

    <!-- inject:css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/line-awesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/jquery-te-1.4.0.css">
    <link rel="stylesheet" href="css/selectize.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- end inject -->
</head>
<body>

<!-- start cssload-loader -->
<div id="preloader">
    <div class="loader">
        <svg class="spinner" viewBox="0 0 50 50">
            <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
        </svg>
    </div>
</div>
<!-- end cssload-loader -->

<!--======================================
        START HEADER AREA
    ======================================-->
<?php include("header.php"); ?> 
<!--======================================
        END HEADER AREA
======================================-->

<!-- ================================
         START QUESTION AREA
================================= -->
<section class="question-area pt-40px pb-40px">
    <div class="container">
        <div class="filters pb-40px d-flex flex-wrap align-items-center justify-content-between">
            <h3 >Create Community</h3>
            <ul class="breadcrumb-list">
                <li><a href="#">Home</a><span><svg xmlns="http://www.w3.org/2000/svg" height="19px" viewBox="0 0 24 24" width="19px" fill="#000000"><path d="M0 0h24v24H0V0z" fill="none"></path><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6-6-6z"></path></svg></span></li>
                <li>Create Community</li>
            </ul>
        </div><!-- end filters -->
     
	  <form action="/action_page.php">
    <div class="col-md-8 mb-3 mt-3">
      <label for="email">Community Name:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
	 <div class="mb-3 col-md-8 mt-3">
      <label for="comment">Description:</label>
      <textarea class="form-control" rows="5" id="comment" name="text"></textarea>
    </div>
    <div class=" col-md-8 mb-3">
      <label for="pwd">Enter Icon name:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd">
    </div>
	  <div class="col-md-8 mb-3">
         <label for="sel1" class="form-label">Select type of Community:</label>
    <select class="form-select" id="sel1" name="sellist1">
      <option>Horizontal </option>
      <option>Vertical</option>
      
    </select>
      </div>
  
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  
  <br><br>
<hr>
<br><br>

  <h3>Community Table</h3>
  <p></p>            
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Community name</th>
        <th>Description</th>
		<th>icon type</th>
		<th>Modify</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>Green Africa</td>
        <td>Post , score, comment, ask questions on agro-allied, agritech, aquaculture, horticulture, farming, greenhouse, food technology, vertical farming and more.</td>
		<td><i class="las la-th"></i></td>
		 <td>
			<div class="dropdown">
			 <i class="la la-list-ul dropdow-toggle" data-bs-toggle="dropdown" style="font-size: 25px;"></i>
            <ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Edit</a></li>
			<li><a class="dropdown-item" href="#">Suspend</a></li>
			<li><a class="dropdown-item" href="#">Unsuspend</a></li>
			<li><a class="dropdown-item" href="#">Delete</a></li>
			</ul>
			</div>
		</td>
      </tr>
      <tr>
        <td>2</td>
        <td>Green Africa</td>
        <td>Post , score, comment, ask questions on agro-allied, agritech, aquaculture, horticulture, farming, greenhouse, food technology, vertical farming and more.</td>
		<td><i class="las la-th"></i></td>
		 <td>
		 <div class="dropdown">
			 <i class="la la-list-ul dropdow-toggle" data-bs-toggle="dropdown" style="font-size: 25px;"></i>
            <ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Edit</a></li>
			<li><a class="dropdown-item" href="#">Suspend</a></li>
			<li><a class="dropdown-item" href="#">Unsuspend</a></li>
			<li><a class="dropdown-item" href="#">Delete</a></li>
			</ul>
			</div>
		 </td>
      </tr>
      <tr>
        <td>3</td>
        <td>Green Africa</td>
        <td>Post , score, comment, ask questions on agro-allied, agritech, aquaculture, horticulture, farming, greenhouse, food technology, vertical farming and more.</td>
		<td><i class="las la-th"></i></td>
		 <td>
		<div class="dropdown">
			 <i class="la la-list-ul dropdow-toggle" data-bs-toggle="dropdown" style="font-size: 25px;"></i>
            <ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Edit</a></li>
			<li><a class="dropdown-item" href="#">Suspend</a></li>
			<li><a class="dropdown-item" href="#">Unsuspend</a></li>
			<li><a class="dropdown-item" href="#">Delete</a></li>
			</ul>
			</div>
		 </td>
      </tr>
    </tbody>
  </table>

	 
    </div><!-- end container -->
</section><!-- end question-area -->
<!-- ================================
         END QUESTION AREA
================================= -->


<!-- start back to top -->
<div id="back-to-top" data-bs-toggle="tooltip" data-placement="top" title="Return to top">
    <i class="la la-arrow-up"></i>
</div>
<!-- end back to top -->

<!-- template js files -->
<script src="js/jquery-3.7.1.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/selectize.min.js"></script>
<script src="js/jquery.multi-file.min.js"></script>
<script src="js/jquery-te-1.4.0.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>