<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title></title>

    <!-- Google fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@300;400;700;900&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" sizes="16x16" href="images/favicon.png">

    <!-- inject:css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/line-awesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/selectize.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- end inject -->
</head>
<body>

<!-- start cssload-loader -->
<div id="preloader">
    <div class="loader">
        <svg class="spinner" viewBox="0 0 50 50">
            <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
        </svg>
    </div>
</div>
<!-- end cssload-loader -->

<!--======================================
        START HEADER AREA
    ======================================-->
<?php include("header.php"); ?> 
<!--======================================
        END HEADER AREA
======================================-->

<!-- ================================
         START QUESTION AREA
================================= -->
<section class="question-area pt-80px pb-30px">
    <div class="container">
        <div class="row">
         
            <div class="col-lg-12 px-0">
                
				    <div class="row">
                        <div class="col-lg-3 responsive-column-half">
                            <div class="media media-card align-items-center shadow-none border border-gray p-3">
                                <div class="icon-element icon-element-sm flex-shrink-0 me-3 bg-1">
                                    <i class="las la-th"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="fw-medium">15332</h5>
                                    <p class="fs-15">Referrals Sent</p>
                                </div>
                            </div>
                        </div><!-- end col-lg-3 -->
                        <div class="col-lg-3 responsive-column-half">
                            <div class="media media-card align-items-center shadow-none border border-gray p-3">
                                <div class="icon-element icon-element-sm flex-shrink-0 me-3 bg-2">
                                   <i class="las la-th"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="fw-medium">466698</h5>
                                    <p class="fs-15">Total Post</p>
                                </div>
                            </div>
                        </div><!-- end col-lg-3 -->
                        <div class="col-lg-3 responsive-column-half">
                            <div class="media media-card align-items-center shadow-none border border-gray p-3">
                                <div class="icon-element icon-element-sm flex-shrink-0 me-3 bg-3">
                                    <svg class="svg-icon-color-white" height="25" viewBox="0 0 515.556 515.556" width="25" xmlns="http://www.w3.org/2000/svg"><path d="m0 274.226 176.549 176.886 339.007-338.672-48.67-47.997-290.337 290-128.553-128.552z"/></svg>
                                </div>
                                <div class="media-body">
                                    <h5 class="fw-medium">11488</h5>
                                    <p class="fs-15">Total Questions</p>
                                </div>
                            </div>
                        </div><!-- end col-lg-3 -->
                        <div class="col-lg-3 responsive-column-half">
                            <div class="media media-card align-items-center shadow-none border border-gray p-3">
                                <div class="icon-element icon-element-sm flex-shrink-0 me-3 bg-4">
                                    <svg class="svg-icon-color-white" width="25" version="1.1" xmlns=<i class="las la-th"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="fw-medium">400</h5>
                                    <p class="fs-15">Online</p>
                                </div>
                            </div>
                        </div><!-- end col-lg-3 -->
                    </div>
					
					    <div class="row">
                        <div class="col-lg-3 responsive-column-half">
                            <div class="media media-card align-items-center shadow-none border border-gray p-3">
                                <div class="icon-element icon-element-sm flex-shrink-0 me-3 bg-1">
                                   <i class="las la-th"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="fw-medium">188745095</h5>
                                    <p class="fs-15">Users</p>
                                </div>
                            </div>
                        </div><!-- end col-lg-3 -->
                        <div class="col-lg-3 responsive-column-half">
                            <div class="media media-card align-items-center shadow-none border border-gray p-3">
                                <div class="icon-element icon-element-sm flex-shrink-0 me-3 bg-2">
                                    <i class="las la-th"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="fw-medium">43569</h5>
                                    <p class="fs-15">Answered</p>
                                </div>
                            </div>
                        </div><!-- end col-lg-3 -->
                        <div class="col-lg-3 responsive-column-half">
                            <div class="media media-card align-items-center shadow-none border border-gray p-3">
                                <div class="icon-element icon-element-sm flex-shrink-0 me-3 bg-3">
                                    <svg class="svg-icon-color-white" height="25" viewBox="0 0 515.556 515.556" width="25" xmlns="http://www.w3.org/2000/svg"><path d="m0 274.226 176.549 176.886 339.007-338.672-48.67-47.997-290.337 290-128.553-128.552z"/></svg>
                                </div>
                                <div class="media-body">
                                    <h5 class="fw-medium">11</h5>
                                    <p class="fs-15">Active Jobs</p>
                                </div>
                            </div>
                        </div><!-- end col-lg-3 -->
                        <div class="col-lg-3 responsive-column-half">
                            <div class="media media-card align-items-center shadow-none border border-gray p-3">
                                <div class="icon-element icon-element-sm flex-shrink-0 me-3 bg-4">
                                  <i class="las la-th"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="fw-medium">400</h5>
                                    <p class="fs-15">Earned</p>
                                </div>
                            </div>
                        </div><!-- end col-lg-3 -->
                    </div>
				
				
            </div><!-- end col-lg-10 -->
         
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end question-area -->
<!-- ================================
         END QUESTION AREA
================================= -->



<!-- ================================
         END FOOTER AREA
================================= -->

<!-- ================================
          END FOOTER AREA
================================= -->

<!-- start back to top -->
<div id="back-to-top" data-bs-toggle="tooltip" data-placement="top" title="Return to top">
    <i class="la la-arrow-up"></i>
</div>
<!-- end back to top -->

<!-- template js files -->
<script src="js/jquery-3.7.1.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/selectize.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>