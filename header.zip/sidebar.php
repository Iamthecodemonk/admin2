<div class="sidenav">
  <a href="manage-communities.php">Manage communities</a>
  <a href="#services">Manage users</a>
  <a href="#clients">Moderate posts</a>
  <a href="#contact">Manage adverts</a>
   <a href="#about">Manage contest</a>
  <a href="#services">Manage admin users</a>
  <a href="#clients">Moderate posts</a>
  <a href="#contact">Manage freelance users</a>
  <button class="dropdown-btn">Jobs 
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">Jobs awaiting approval</a>
    <a href="#">Manage active jobs</a>
    <a href="#">View in-active jobs</a>
  </div>
  <a href="#contact">Search</a>
</div><!-- end sidebar -->