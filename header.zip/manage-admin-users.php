<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

      <title>Skills4Export.com|</title>

    <!-- Google fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" sizes="16x16" href="images/favicon.png">

    <!-- inject:css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/line-awesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- end inject -->
</head>
<body>

<!-- start cssload-loader -->
<div id="preloader">
    <div class="loader">
        <svg class="spinner" viewBox="0 0 50 50">
            <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
        </svg>
    </div>
</div>
<!-- end cssload-loader -->

<!--======================================
        START HEADER AREA
    ======================================-->
<?php include("header.php"); ?> 
<!--======================================
        END HEADER AREA
======================================-->

<!-- ================================
         START QUESTION AREA
================================= -->
<section class="question-area pt-40px pb-40px">
    <div class="container">
   <div class="filters pb-3">
            <div class="d-flex flex-wrap align-items-center justify-content-between pb-3">
                <h3 class="fs-22 fw-medium">Manage Admin Users <small class="fs-5" style="color:#f1f1f1"></small></h3>
                
            </div>
            <!--<div class="d-flex flex-wrap align-items-center justify-content-between">
                <form method="post" class="me-3 w-25">
                    <div class="form-group">
                        <input class="form-control form--control form-control-sm h-auto lh-34" type="text" name="search" placeholder="Search username or email">
                        <button class="form-btn" type="button"><i class="la la-search"></i></button>
                    </div>
                </form>
                
            </div>-->
        </div><!-- end filters -->
        
       
		
	
            
             <form action="/action_page.php">
			 <div class="mb-3 mt-3">
      <label for="email">Enter User Name:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
			 <div class="mb-3 mt-3">
      <label for="email">Enter User Phone:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
    <div class="mb-3 mt-3">
      <label for="email">Enter User Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
	<div class="mb-3 mt-3">
        <label for="sel1" class="form-label">Select User Permission (select one): <small style="font-size:px">permissions level 1 - (CAN NOT create, suspend or delete admin users), Level 2 - (CAN create, suspend or delete admin users)</small></label>
    <select class="form-select" id="sel1" name="sellist1">
      <option>1</option>
      <option>2</option>
  
    </select>
	</div>
   <br> 
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
            
       
		
		<br><br><hr><br>
		
		                        <h3 class="fs-20 pb-3">View and Edit Submissions</h3><br>
                       <table class="table table-bordered">
    <thead>
      <tr>
        <th>No</th>
        <th>Admin User Name</th>
        <th>Admin User Phone</th>
		<th>Admin User Email	</th>
		<th>Admin User Permission</th>
		<th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td></td>
        <td></td>
		<td></td>
        <td></td>
		<td><div class="dropdown">
							 <i class="la la-list-ul dropdow-toggle" data-bs-toggle="dropdown" style="font-size: 25px;"></i>
    
    <ul class="dropdown-menu">
      <li><a class="dropdown-item" href="#">Edit</a></li>
      <li><a class="dropdown-item" href="#">Save</a></li>
      <li><a class="dropdown-item" href="#">Delete</a></li>
    </ul>
  </div></td>
      </tr>
     

    </tbody>
  </table>
       
		</div>
		
		
    </div><!-- end container -->
</section><!-- end question-area -->
<!-- ================================
         END QUESTION AREA
================================= -->

<!-- ================================
         END FOOTER AREA
================================= -->

<!-- ================================
          END FOOTER AREA
================================= -->


<!-- The Modal -->
<div class="modal" id="awardscoresModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Award scores based on qualification</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <form action="php/contact.php" class="contact-form card card-item">
           
              
                    
                    <div class="form-group">
                        <label class="fs-14 text-black fw-medium lh-20">Select Community </label>
                        <select class="form-control form-control-md rounded-0 g-mb-25">
    <option>Select Community</option>
    <option value="1">Main feeds</option>
    <option value="2">News headlines</option>
    <option value="3">Community 1</option>
	<option value="4">Community 2</option>
  </select>
                    </div><!-- end form-group -->
                    <div class="form-group">
                        <label class="fs-14 text-black fw-medium lh-20">Add qualification: </span></label>
                        <input type="number" id="" name="" class="form-control form--control fs-14" placeholder="Phd. Electrical, ">
                    </div><!-- end form-group -->
                    <div class="form-group">
                        <label class="fs-14 text-black fw-medium lh-20">Award scores - value:</label>
                        <input type="tel" id="phone-number" name="phone" class="form-control form--control fs-14" placeholder="100">
                    </div><!-- end form-group -->
					
					<button type="submit" class="btn btn-primary">Update</button>
					
					</form>
					

      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>



<!-- start back to top -->
<div id="back-to-top" data-bs-toggle="tooltip" data-placement="top" title="Return to top">
    <i class="la la-arrow-up"></i>
</div>
<!-- end back to top -->

<!-- template js files -->
<script src="js/jquery-3.7.1.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>