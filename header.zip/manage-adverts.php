<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>admin</title>

    <!-- Google fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" sizes="16x16" href="images/favicon.png">

    <!-- inject:css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/line-awesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/jquery-te-1.4.0.css">
    <link rel="stylesheet" href="css/selectize.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- end inject -->
</head>
<body>

<!-- start cssload-loader -->
<div id="preloader">
    <div class="loader">
        <svg class="spinner" viewBox="0 0 50 50">
            <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
        </svg>
    </div>
</div>
<!-- end cssload-loader -->

<!--======================================
        START HEADER AREA
    ======================================-->
<?php include("header.php"); ?> 
<!--======================================
        END HEADER AREA
======================================-->

<!-- ================================
         START QUESTION AREA
================================= -->
<section class="question-area pt-40px pb-40px">
    <div class="container">
        <div class="filters pb-40px d-flex flex-wrap align-items-center justify-content-between">
            <h3 class="fs-32 fw-medium mr-0">Manage Adverts</h3>
            <ul class="breadcrumb-list">
                <li><a href="#">Home</a><span><svg xmlns="http://www.w3.org/2000/svg" height="19px" viewBox="0 0 24 24" width="19px" fill="#000000"><path d="M0 0h24v24H0V0z" fill="none"></path><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6-6-6z"></path></svg></span></li>
                <li>Manage Adverts</li>
            </ul>
        </div><!-- end filters -->
    
		 <form>
	 <fieldset>
	 <legend>Maintain AD Location:</legend>
    <div class="row">
      <div class="col-md-4 mb-3">
         <label for="sel1" class="form-label">AD Location:</label>
    <input type="text" class="form-control" placeholder="enter AD page locations, e.g - Feeds, home page " name="ad-address">
      </div>
      <div class="col-md-4 mb-3">
      <table class="table table-bordered">
    <thead>
      <tr>
        <th>Location ID</th>
        <th>AD location</th>
        <th>Modify</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>01</td>
        <td>All Community</td>
         <td>
		 <div class="dropdown">
			 <i class="la la-list-ul dropdow-toggle" data-bs-toggle="dropdown" style="font-size: 25px;"></i>
            <ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Edit</a></li>
			<li><a class="dropdown-item" href="#">Suspend</a></li>
			<li><a class="dropdown-item" href="#">Unsuspend</a></li>
			<li><a class="dropdown-item" href="#">Delete</a></li>
			</ul>
			</div>
		 </td>
      </tr>
     
    </tbody>
  </table>
      </div>
	  
	 
    </div>
 
   
	
	
    <button type="submit" class="btn btn-primary">Submit</button>
	</fieldset>
  </form>
	<hr>
	<br>
	
			 <form>
	 <fieldset>
	 <legend>Maintain AD Size:</legend>
    <div class="row">
      <div class="col-md-4 mb-3">
         <label for="sel1" class="form-label">AD Size:</label>
    <input type="text" class="form-control" placeholder="enter AD page locations, e.g - Feeds, home page " name="ad-address">
      </div>
      <div class="col-md-4 mb-3">
      <table class="table table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>AD Size</th>
        <th>Modify</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>01</td>
        <td>290x500</td>
         <td>
		 <div class="dropdown">
			 <i class="la la-list-ul dropdow-toggle" data-bs-toggle="dropdown" style="font-size: 25px;"></i>
            <ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Edit</a></li>
			<li><a class="dropdown-item" href="#">Suspend</a></li>
			<li><a class="dropdown-item" href="#">Unsuspend</a></li>
			<li><a class="dropdown-item" href="#">Delete</a></li>
			</ul>
			</div>
		 </td>
      </tr>
     
    </tbody>
  </table>
      </div>
	  
	 
    </div>
 
   
	
	
    <button type="submit" class="btn btn-primary">Submit</button>
	</fieldset>
  </form>
	<hr>
	<br>
	
	
	
	 <form>
	 <fieldset>
	 <legend>Create Adverts:</legend>
    <div class="row">
      <div class="col-md-4 mb-3">
         <label for="sel1" class="form-label">Page Location:</label>
    <select class="form-select" id="sel1" name="sellist1">
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
    </select>
      </div>
      <div class="col-md-4 mb-3">
      <label for="sel1" class="form-label">Duration(hours):</label>
        <input type="text" class="form-control" placeholder="24" name="email">
      </div>
	  
	  <div class="col-md-4 mb-3">
         <label for="sel1" class="form-label">AD Size:</label>
    <select class="form-select" id="sel1" name="sellist1">
      <option>290x500</option>
      <option>290x300</option>
      <option>450x400</option>
      <option>banner</option>
    </select>
      </div>
    </div>
 
     <div class="row">
     
      <div class="col-md-4 mb-3">
        <label for="sel1" class="form-label">Upload image:</label>
    <input type="file" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp">
      </div>
	  
	  <div class="col-md-4 mb-3">
         <label for="sel1" class="form-label">Link URL:</label>
     <input type="text" class="form-control" placeholder="www.xlehub.com" name="link">
      </div>
	  <div class="col-md-4 mb-3">
         <label for="sel1" class="form-label">Approved by:</label>
     <input type="text" class="form-control" placeholder="john Doe" name="link">
      </div>
    </div>
	
	 <div class="row">
     
       
	   <div class="col-md-4 mb-3">
         <label for="sel1" class="form-label">Ad Owner:</label>
     <input type="text" class="form-control" placeholder="john Doe, elixis ltd" name="link">
      </div>
	  <div class="col-md-4 mb-3">
         <label for="sel1" class="form-label">Contact:</label>
     <input type="number" class="form-control" placeholder="phone number" name="link">
      </div>
    </div>
    <button type="submit" class="btn btn-primary">Create new advert</button>
	</fieldset>
  </form>
  
  <br><br>
<hr>
<br><br>

  <h2>Adverts Table</h2>
  <p></p>            
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>#</th>
        <th>Page<br> location</th>
        <th>Duration<br> in hours</th>
		<th>AD Size</th>
		<th>AD Link</th>
		<th>AD Image link</th>
		<th>Owner(name)</th>
		<th>Contact<br>Phone</th>
		<th>Approved by</th>
		<th>Status<br>active/expired</th>
		<th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>01</td>
        <td>Green Africa</td>
        <td>24</td>
		<td>290x500</td>
		<td><a href="#">www.xyz.com</a></td>
		<td><a href="images/team.jpg">Click here to view image</a> </td>
        <td>Green Africa</td>
        <td>08025552000</td>
		<td>john@example.com</td>
		<td>Active</td>
		 <td>
		 <div class="dropdown">
			 <i class="la la-list-ul dropdow-toggle" data-bs-toggle="dropdown" style="font-size: 25px;"></i>
            <ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Edit</a></li>
			<li><a class="dropdown-item" href="#">Suspend</a></li>
			<li><a class="dropdown-item" href="#">Unsuspend</a></li>
			<li><a class="dropdown-item" href="#">Delete</a></li>
			</ul>
			</div>
		 </td>
      </tr>
      </tbody>
  </table>

	 
    </div><!-- end container -->
</section><!-- end question-area -->
<!-- ================================
         END QUESTION AREA
================================= -->


<!-- start back to top -->
<div id="back-to-top" data-bs-toggle="tooltip" data-placement="top" title="Return to top">
    <i class="la la-arrow-up"></i>
</div>
<!-- end back to top -->

<!-- template js files -->
<script src="js/jquery-3.7.1.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/selectize.min.js"></script>
<script src="js/jquery.multi-file.min.js"></script>
<script src="js/jquery-te-1.4.0.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>