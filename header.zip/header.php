<header class="header-area bg-white shadow-sm">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-1">
                <div class="logo-box">
                    <a href="index.php" class="logo">Admin</a>
                    <div class="user-action">
                        <div class="search-menu-toggle icon-element icon-element-xs shadow-sm me-1" data-bs-toggle="tooltip" data-placement="top" title="Search">
                            <i class="la la-search"></i>
                        </div>
                        <div class="off-canvas-menu-toggle icon-element icon-element-xs shadow-sm" data-bs-toggle="tooltip" data-placement="top" title="Main menu">
                            <i class="la la-bars"></i>
                        </div>
                    </div>
                </div>
            </div><!-- end col-lg-2 -->
            <div class="col-lg-11">
                <div class="menu-wrapper border-left border-left-gray ps-4 justify-content-end">
                    <nav class="menu-bar me-auto menu--bar">
                        <ul>
                            <li>
                                <a href="#">Home </a>
                            </li>
							<li>
                                <a href="manage-Communities.php">Mng Communities</a>
                            </li>
							<li>
                                <a href="manage-adverts.php">Mng Adverts</a>
                            </li>
							<li>
                                <a href="moderate-posts.php">Moderate Posts</a>
                            </li>
							<li>
                                <a href="#">Mng Contests</a>
                            </li>
							 <li>
                                <a href="#">Jobs <i class="la la-angle-down fs-11"></i></a>
                                <ul class="dropdown-menu-item">
                                    <li><a href="jobs-awaiting-approval.php">Jobs awaiting approval</a></li>
                                    <li><a href="manage-active-jobs.php">Manage active jobs</a></li>
                                   
                                </ul>
                            </li>
							<!--<li>
                                <a href="#">Freelance Jobs <i class="la la-angle-down fs-11"></i></a>
                                <ul class="dropdown-menu-item">
                                  <li><a href="blog-left-sidebar.html">Mng Freelance users</a></li>
                                    <li><a href="blog-right-sidebar.html">Mng freelance jobs</a></li>
                                    <li><a href="blog-single.html">freelance jobs awaiting approval</a></li>
                                </ul>
                            </li>-->
                         
                            <li>
                                <a href="#">Users <i class="la la-angle-down fs-11"></i></a>
                                <ul class="dropdown-menu-item">
                                    <li><a href="manage-users.php">Manage users</a></li>
                                    
                                    <li><a href="manage-admin-users.php">Manage Admin users</a></li>
                                 
                                </ul>
                            </li>
                        </ul><!-- end ul -->
                    </nav><!-- end main-menu -->
                 
                </div><!-- end menu-wrapper -->
            </div><!-- end col-lg-10 -->
        </div><!-- end row -->
    </div><!-- end container -->
    <div class="off-canvas-menu custom-scrollbar-styled">
        <div class="off-canvas-menu-close icon-element icon-element-sm shadow-sm" data-bs-toggle="tooltip" data-placement="left" title="Close menu">
            <i class="la la-times"></i>
        </div><!-- end off-canvas-menu-close -->
        <ul class="generic-list-item off-canvas-menu-list pt-90px">
            <li>
                <a href="#">Home</a>
                <ul class="sub-menu">
                    <li><a href="index.html">Home - landing</a></li>
                    <li><a href="home-2.html">Home - main</a></li>
                </ul>
            </li>
         
            <li>
                <a href="#">blog</a>
                <ul class="sub-menu">
                    <li><a href="blog-grid-no-sidebar.html">grid no sidebar</a></li>
                    <li><a href="blog-left-sidebar.html">blog left sidebar</a></li>
                    <li><a href="blog-right-sidebar.html">blog right sidebar</a></li>
                    <li><a href="blog-single.html">blog detail</a></li>
                </ul>
            </li>
        </ul>
     
    </div><!-- end off-canvas-menu -->
   
    <div class="body-overlay"></div>
</header><!-- end header-area -->