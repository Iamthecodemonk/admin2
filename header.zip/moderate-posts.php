<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="TechyDevs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>admin</title>

    <!-- Google fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" sizes="16x16" href="images/favicon.png">

    <!-- inject:css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/line-awesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/jquery-te-1.4.0.css">
    <link rel="stylesheet" href="css/selectize.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- end inject -->
</head>
<body>

<!-- start cssload-loader -->
<div id="preloader">
    <div class="loader">
        <svg class="spinner" viewBox="0 0 50 50">
            <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
        </svg>
    </div>
</div>
<!-- end cssload-loader -->

<!--======================================
        START HEADER AREA
    ======================================-->
<?php include("header.php"); ?> 
<!--======================================
        END HEADER AREA
======================================-->

<!-- ================================
         START QUESTION AREA
================================= -->
<section class="question-area pt-40px pb-40px">
    <div class="container">
       <div class="filters pb-3">
            <div class="d-flex flex-wrap align-items-center justify-content-between pb-3">
                <h3 class="fs-22 fw-medium">Moderate Posts</h3>
               <!-- <a href="ask-question.html" class="btn theme-btn theme-btn-sm">Ask Question</a>-->
            </div>
            <div class="d-flex flex-wrap align-items-center justify-content-between">
                <form method="post" class="me-3 w-25">
                    <div class="form-group">
                        <input class="form-control form--control form-control-sm h-auto lh-34" type="text" name="search" placeholder="Filter by username or email">
                        <button class="form-btn" type="button"><i class="la la-search"></i></button>
                    </div>
                </form>
                <div class="btn-group btn--group mb-3">
                    <input type="radio" class="btn-check" name="btnradio" id="btnradio1" checked>
                    <label class="btn btn-outline-primary" for="btnradio1">Awaiting review</label>
                  
                 <input type="radio" class="btn-check" name="btnradio" id="btnradio2">
                    <label class="btn btn-outline-primary" for="btnradio2">Reviewed</label>
                  
                       <!--<input type="radio" class="btn-check" name="btnradio" id="btnradio3">
                    <label class="btn btn-outline-primary" for="btnradio3">Votes</label>
                    
                    <input type="radio" class="btn-check" name="btnradio" id="btnradio4">
                    <label class="btn btn-outline-primary" for="btnradio4">Editors</label>
                    
                    <input type="radio" class="btn-check" name="btnradio" id="btnradio5">
                    <label class="btn btn-outline-primary" for="btnradio5">Moderators</label>-->
                </div>
            </div>
        </div><!-- end filters -->
   
  
  <br><br>
<hr>
<br><br>

  <h3>Report Table</h3>
  <p></p>   
  <div class="table-responsive">  
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>#</th>
		<th>post id</th>
        <th>name (profile link)</th>
        <th>rule violated</th>
		<th>Post <br>Content</th>
		<th>post link</th>
		<th>image(if any)</th>
		<th>Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>0021</td>
        <td><a href="#">Adren young</a></td>
		<td>Spam</td>
		<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</td>
		<td><a href="#">Post link</a></td>
		<td> <a href="images/team.jpg">Click here to view image</a> </td>
		 <td>
			<div class="dropdown">
			 <i class="la la-list-ul dropdow-toggle" data-bs-toggle="dropdown" style="font-size: 25px;"></i>
            <ul class="dropdown-menu">
			<li><a class="dropdown-item" href="#">Edit</a></li>
			<li><a class="dropdown-item" href="#">Suspend</a></li>
			<li><a class="dropdown-item" href="#">Unsuspend</a></li>
			<li><a class="dropdown-item" href="#">Delete</a></li>
			</ul>
			</div>
		</td>
      </tr>
     
     
    </tbody>
  </table>
 </div>
	 
    </div><!-- end container -->
</section><!-- end question-area -->
<!-- ================================
         END QUESTION AREA
================================= -->


<!-- start back to top -->
<div id="back-to-top" data-bs-toggle="tooltip" data-placement="top" title="Return to top">
    <i class="la la-arrow-up"></i>
</div>
<!-- end back to top -->

<!-- template js files -->
<script src="js/jquery-3.7.1.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/selectize.min.js"></script>
<script src="js/jquery.multi-file.min.js"></script>
<script src="js/jquery-te-1.4.0.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>